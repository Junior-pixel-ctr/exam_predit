(function () {
  "use strict";
  var MAX_CHARS = 12000;
  var MIN_CHARS = 50;
  var TIMEOUT_MS = 10 * 60 * 1000; // local models can be slow
  var lastAnalysis = "";
  var lastSubject = "";
  var busy = false;

  function $(id) { return document.getElementById(id); }
  var el = {
    form: $("form"), subject: $("subject"), questions: $("questions"), counter: $("counter"),
    submit: $("submit"), sample: $("sample"), formError: $("form-error"), loading: $("loading"),
    results: $("results"), sections: $("sections"), title: $("results-title"),
    copy: $("copy"), download: $("download"), actionMsg: $("action-msg"),
    status: $("status"), statusText: $("status-text"), healthNote: $("health-note")
  };

  var SAMPLE = {
    subject: "Database Management",
    questions:
      "SAMPLE DATA (illustrative only, not real examination records)\n\n" +
      "2021\n1. Define normalization and explain 1NF, 2NF and 3NF with examples.\n2. Write SQL to find the total salary per department.\n3. Explain the ACID properties of a transaction.\n\n" +
      "2022\n1. Draw an ER diagram for a library system and convert it to relational tables.\n2. Differentiate between primary key and foreign key.\n3. Explain the role of indexes in query performance.\n\n" +
      "2023\n1. Normalize the following table to 3NF and justify each step.\n2. Write SQL using a JOIN to list students and their courses.\n3. Describe deadlock in a DBMS and how it can be prevented."
  };

  /* ---------- helpers ---------- */
  function show(node, on) { node.hidden = !on; }
  function showFormError(msg) { el.formError.textContent = msg; show(el.formError, true); }
  function clearFormError() { show(el.formError, false); el.formError.textContent = ""; }
  function updateCounter() {
    var n = el.questions.value.length;
    el.counter.textContent = n.toLocaleString("en-US") + " / " + MAX_CHARS.toLocaleString("en-US");
    el.counter.classList.toggle("over", n > MAX_CHARS);
    el.counter.textContent += n > MAX_CHARS ? " (too long)" : "";
  }

  /* ---------- health ---------- */
  function setStatus(state, text) {
    el.status.dataset.state = state;
    el.statusText.textContent = text;
  }
  // The exact /health field names are not confirmed, so common variants are checked.
  function pick(obj, names) {
    for (var i = 0; i < names.length; i++) if (names[i] in obj) return obj[names[i]];
    return undefined;
  }
  function checkHealth() {
    setStatus("checking", "Checking service…");
    show(el.healthNote, false);
    fetch("/health", { headers: { Accept: "application/json" } })
      .then(function (r) { return r.json(); })
      .then(function (d) {
        var ollama = pick(d, ["ollama", "ollama_running", "ollama_available", "ollama_connected", "ollama_ok"]);
        var model = pick(d, ["model_available", "model_installed", "model_ready", "model_found", "model_ok"]);
        if (typeof ollama === "string") ollama = /^(ok|up|online|running|connected|true)$/i.test(ollama);
        if (ollama === undefined && typeof d.status === "string") ollama = /^(ok|healthy|up)$/i.test(d.status);
        if (ollama === false) {
          setStatus("bad", "Ollama unavailable");
          return note("The local AI service is not running. Start Ollama, then click the status button to check again.");
        }
        if (model === false) {
          setStatus("bad", "Configured model unavailable");
          return note("Ollama is running, but the configured Gemma model is not installed. Install the model named in app.py (for example with 'ollama pull <model>'), then check again.");
        }
        if (ollama === true && model === true) return setStatus("ok", "AI service available");
        setStatus("unknown", "Unable to determine service status");
      })
      .catch(function () {
        setStatus("unknown", "Unable to determine service status");
        note("Could not reach the Flask server. Make sure app.py is running.");
      });
  }
  function note(msg) { el.healthNote.textContent = msg; show(el.healthNote, true); }

  /* ---------- parsing the analysis text ---------- */
  var HEADINGS = [
    { key: "topic", re: /topic analysis/i, title: "Topic analysis", tag: "Observed patterns", cls: "obs" },
    { key: "freq", re: /historical frequency/i, title: "Historical frequency", tag: "Observed patterns", cls: "obs" },
    { key: "practice", re: /(five\s+)?practice questions?/i, title: "Practice questions", tag: "AI-generated", cls: "ai" },
    { key: "revise", re: /revision recommendations?/i, title: "Revision recommendations", tag: "General advice", cls: "" },
    { key: "limit", re: /important limitation/i, title: "Important limitation", tag: "Please note", cls: "" }
  ];
  function stripMarks(line) {
    return line.replace(/^\s{0,3}#{1,6}\s*/, "").replace(/^\s*(\d+[.)]\s*)?/, "").replace(/[*_`:]/g, "").trim();
  }
  function matchHeading(line) {
    var t = line.trim();
    if (!t || t.length > 70) return null;
    var looksLikeHeading = /^#{1,6}\s/.test(t) || /^\*\*.+\*\*:?$/.test(t) || /^(\d+[.)]\s*)?[A-Za-z ]+:?$/.test(t);
    if (!looksLikeHeading) return null;
    var clean = stripMarks(t);
    for (var i = 0; i < HEADINGS.length; i++) if (HEADINGS[i].re.test(clean) && clean.length < 45) return HEADINGS[i];
    return null;
  }
  function splitSections(text) {
    var lines = text.split(/\r?\n/), out = [], cur = null, intro = [];
    lines.forEach(function (line) {
      var h = matchHeading(line);
      if (h) { cur = { def: h, lines: [] }; out.push(cur); }
      else if (cur) cur.lines.push(line);
      else intro.push(line);
    });
    if (!out.length) return [{ def: null, lines: lines }];
    if (intro.join("").trim()) out.unshift({ def: null, lines: intro });
    return out;
  }

  /* ---------- safe rendering (textContent only) ---------- */
  function inline(parent, text) {
    text.split(/(\*\*[^*]+\*\*)/).forEach(function (part) {
      if (/^\*\*[^*]+\*\*$/.test(part)) {
        var b = document.createElement("strong"); b.textContent = part.slice(2, -2); parent.appendChild(b);
      } else if (part) parent.appendChild(document.createTextNode(part));
    });
  }
  function renderBody(container, lines, isPractice) {
    var list = null, listType = null, para = [];
    function flushPara() {
      if (para.length) { var p = document.createElement("p"); inline(p, para.join(" ")); container.appendChild(p); para = []; }
    }
    lines.forEach(function (raw) {
      var line = raw.replace(/\s+$/, "");
      var num = line.match(/^\s*\d+[.)]\s+(.*)$/);
      var bul = line.match(/^\s*[-*•]\s+(.*)$/);
      if (!line.trim()) { flushPara(); list = null; return; }
      if (num || bul) {
        flushPara();
        var type = num ? "ol" : "ul";
        if (!list || listType !== type) {
          list = document.createElement(type); listType = type;
          if (isPractice) list.className = "practice";
          container.appendChild(list);
        }
        var li = document.createElement("li"); inline(li, (num || bul)[1]); list.appendChild(li);
      } else { list = null; para.push(line.trim()); }
    });
    flushPara();
  }
  function renderResults(subject, text) {
    el.sections.textContent = "";
    el.title.textContent = "Results: " + subject;
    splitSections(text).forEach(function (s) {
      var card = document.createElement("article"); card.className = "card";
      if (s.def) {
        var tag = document.createElement("span"); tag.className = "tag " + s.def.cls; tag.textContent = s.def.tag;
        var h = document.createElement("h3"); h.textContent = s.def.title;
        card.appendChild(tag); card.appendChild(h);
      }
      renderBody(card, s.lines, s.def && s.def.key === "practice");
      if (card.textContent.trim()) el.sections.appendChild(card);
    });
    show(el.results, true);
    el.results.focus();
    el.results.scrollIntoView({ behavior: "smooth", block: "start" });
  }

  /* ---------- submit ---------- */
  function setBusy(on) {
    busy = on;
    el.submit.disabled = on;
    el.submit.textContent = on ? "Analyzing…" : "Analyze my examination papers";
    show(el.loading, on);
    if (on) el.loading.scrollIntoView({ behavior: "smooth", block: "nearest" });
  }
  function validate(subject, questions) {
    if (!subject) return "Enter a subject before analyzing.";
    if (questions.trim().length < MIN_CHARS) return "Paste more examination material (at least " + MIN_CHARS + " characters). Several years of questions give better results.";
    if (questions.length > MAX_CHARS) return "The material is " + (questions.length - MAX_CHARS).toLocaleString("en-US") + " characters over the " + MAX_CHARS.toLocaleString("en-US") + " limit. Remove some questions and try again.";
    return "";
  }
  function friendlyError(status, data) {
    if (data && typeof data.error === "string" && data.error) return data.error;
    if (status === 400) return "The server rejected the request. Check the subject and examination material.";
    if (status === 503 || status === 502) return "The AI service is unavailable. Start Ollama and make sure the configured model is installed.";
    return "Something went wrong on the server. Please try again.";
  }
  function onSubmit(e) {
    e.preventDefault();
    if (busy) return;
    clearFormError();
    var subject = el.subject.value.trim(), questions = el.questions.value;
    var problem = validate(subject, questions);
    if (problem) return showFormError(problem);

    setBusy(true);
    var ctrl = new AbortController();
    var timer = setTimeout(function () { ctrl.abort(); }, TIMEOUT_MS);
    fetch("/analyze", {
      method: "POST",
      headers: { "Content-Type": "application/json", Accept: "application/json" },
      body: JSON.stringify({ subject: subject, questions: questions }),
      signal: ctrl.signal
    })
      .then(function (r) {
        return r.text().then(function (raw) {
          var data = null;
          try { data = JSON.parse(raw); } catch (err) { /* handled below */ }
          if (!r.ok) throw new Error(friendlyError(r.status, data));
          if (!data || typeof data.analysis !== "string") throw new Error("The server sent a response this page could not read. Please try again.");
          return data;
        });
      })
      .then(function (data) {
        lastSubject = data.subject || subject;
        lastAnalysis = data.analysis;
        renderResults(lastSubject, lastAnalysis);
      })
      .catch(function (err) {
        var msg = err.name === "AbortError"
          ? "The analysis took too long and was stopped. Try shorter material or check that your computer can run the model."
          : (err instanceof TypeError ? "Could not reach the server. Check that app.py is running, then try again." : err.message);
        showFormError(msg + " Your material has been kept.");
        checkHealth();
      })
      .then(function () { clearTimeout(timer); setBusy(false); });
  }

  /* ---------- copy / download ---------- */
  function say(msg) { el.actionMsg.textContent = msg; }
  function fullText() { return "ExamPredict AI – " + lastSubject + "\n\n" + lastAnalysis; }
  function onCopy() {
    if (!lastAnalysis) return;
    var done = function () { el.copy.textContent = "Copied"; say("Analysis copied to clipboard."); setTimeout(reset, 2000); };
    var fail = function () { el.copy.textContent = "Copy failed"; say("Copy failed. Select the text manually or use Download as .txt."); setTimeout(reset, 3000); };
    function reset() { el.copy.textContent = "Copy analysis"; }
    if (navigator.clipboard && window.isSecureContext) navigator.clipboard.writeText(fullText()).then(done, fail);
    else {
      var ta = document.createElement("textarea"); ta.value = fullText(); ta.style.position = "fixed"; ta.style.opacity = "0";
      document.body.appendChild(ta); ta.select();
      var ok = false; try { ok = document.execCommand("copy"); } catch (err) { ok = false; }
      document.body.removeChild(ta); ok ? done() : fail();
    }
  }
  function onDownload() {
    if (!lastAnalysis) return;
    var blob = new Blob([fullText()], { type: "text/plain;charset=utf-8" });
    var a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = "exampredict-" + (lastSubject.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") || "analysis") + ".txt";
    document.body.appendChild(a); a.click(); document.body.removeChild(a);
    setTimeout(function () { URL.revokeObjectURL(a.href); }, 1000);
    say("Download started.");
  }

  /* ---------- wire up ---------- */
  el.form.addEventListener("submit", onSubmit);
  el.questions.addEventListener("input", updateCounter);
  el.sample.addEventListener("click", function () {
    el.subject.value = SAMPLE.subject; el.questions.value = SAMPLE.questions;
    updateCounter(); clearFormError(); el.questions.focus();
  });
  el.copy.addEventListener("click", onCopy);
  el.download.addEventListener("click", onDownload);
  el.status.addEventListener("click", checkHealth);
  updateCounter();
  checkHealth();
})();
