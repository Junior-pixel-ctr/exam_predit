# ExamPredict AI

AI-powered exam preparation: paste past exam questions, get topic patterns, practice questions and revision advice.
Stack: Flask + Ollama (Gemma) backend, vanilla HTML/CSS/JS frontend.

## Run
1. Install and start Ollama, then install the model named in `app.py` (`ollama pull <model>`).
2. `pip install -r requirements.txt`
3. `python app.py` and open the address Flask prints (usually http://127.0.0.1:5000).

## Backend contract used by the frontend
- `GET /health` – Ollama and model status (status badge in the header).
- `POST /analyze` – JSON `{ "subject": "...", "questions": "..." }` returns `{ "subject": "...", "analysis": "..." }`. Max 12,000 characters.

## Manual test checklist
- Header badge: stop Ollama (should say "Ollama unavailable"), remove the model ("Configured model unavailable"), stop Flask ("Unable to determine"), normal ("AI service available").
- Empty subject, too-short text and text over 12,000 characters show errors and keep your input.
- "Try a sample" fills the form but does not submit.
- Submit shows a spinner and disables the button; results appear as cards.
- Copy analysis and Download as .txt work; check at 360px, 768px and 1440px widths.
